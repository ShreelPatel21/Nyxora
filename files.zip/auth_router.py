"""
Nyxora Auth Router
------------------
Implements the login flows from the requirements spec:
  - Email + password
  - Phone number + OTP
  - Google / Apple / Facebook OAuth (provider exchange stubs)
  - JWT access + refresh tokens, with "Remember Me" -> long-lived refresh cookie
  - GET /auth/session lets the frontend silently skip the login screen
    and redirect straight to Home if a valid session exists.

Drop into a FastAPI app with: app.include_router(auth_router, prefix="/auth")
Replace the stubbed DB / provider-exchange functions with real integrations.
"""

from datetime import datetime, timedelta, timezone
from typing import Optional
import random
import string

from fastapi import APIRouter, Depends, HTTPException, Response, Request, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, EmailStr
import jwt
from passlib.context import CryptContext

# --------------------------------------------------------------------------
# Config (move to env vars / settings module in production)
# --------------------------------------------------------------------------
JWT_SECRET = "REPLACE_WITH_ENV_SECRET"
JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_TTL = timedelta(minutes=15)
REFRESH_TOKEN_TTL_DEFAULT = timedelta(days=1)      # not "remember me"
REFRESH_TOKEN_TTL_REMEMBER = timedelta(days=30)    # "remember me" checked
REFRESH_COOKIE_NAME = "nyxora_refresh"

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login/email", auto_error=False)

auth_router = APIRouter(tags=["auth"])

# --------------------------------------------------------------------------
# Schemas
# --------------------------------------------------------------------------
class EmailLoginRequest(BaseModel):
    email: EmailStr
    password: str
    remember_me: bool = True

class PhoneOtpRequestModel(BaseModel):
    phone_number: str

class PhoneOtpVerifyModel(BaseModel):
    phone_number: str
    otp_code: str
    remember_me: bool = True

class OAuthExchangeRequest(BaseModel):
    provider: str          # "google" | "apple" | "facebook"
    id_token: str          # token issued by the provider's SDK on the client
    remember_me: bool = True

class TokenPair(BaseModel):
    access_token: str
    token_type: str = "bearer"
    redirect_to: str = "/home"   # Login Redirect Rule: always Home, no setup screens


# --------------------------------------------------------------------------
# Fake persistence layer — replace with real DB calls
# --------------------------------------------------------------------------
_fake_users_db = {}          # email -> {hashed_password, user_id}
_fake_otp_store = {}         # phone_number -> {code, expires_at}


def get_user_by_email(email: str) -> Optional[dict]:
    return _fake_users_db.get(email)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


def generate_otp() -> str:
    return "".join(random.choices(string.digits, k=6))


def send_otp_sms(phone_number: str, code: str) -> None:
    # Wire up to Twilio / MSG91 / etc. Never log the code in production.
    print(f"[stub] sending OTP {code} to {phone_number}")


def exchange_oauth_token(provider: str, id_token: str) -> dict:
    """
    Stub: verify id_token with the provider's public keys / API and
    return a normalized user dict. Replace with real verification
    (google-auth, apple's JWKS, Facebook Graph API) before shipping.
    """
    if provider not in {"google", "apple", "facebook"}:
        raise HTTPException(status_code=400, detail="Unsupported provider")
    return {"user_id": f"{provider}:demo-user", "email": f"demo@{provider}.example"}


# --------------------------------------------------------------------------
# Token helpers
# --------------------------------------------------------------------------
def create_jwt(subject: str, ttl: timedelta, token_type: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {"sub": subject, "type": token_type, "iat": now, "exp": now + ttl}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_jwt(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")


def issue_token_pair(response: Response, subject: str, remember_me: bool) -> TokenPair:
    access = create_jwt(subject, ACCESS_TOKEN_TTL, "access")
    refresh_ttl = REFRESH_TOKEN_TTL_REMEMBER if remember_me else REFRESH_TOKEN_TTL_DEFAULT
    refresh = create_jwt(subject, refresh_ttl, "refresh")

    # Refresh token lives in an httpOnly cookie -- never exposed to JS,
    # so a stolen access token alone can't extend the session.
    response.set_cookie(
        key=REFRESH_COOKIE_NAME,
        value=refresh,
        httponly=True,
        secure=True,
        samesite="lax",
        max_age=int(refresh_ttl.total_seconds()),
    )
    return TokenPair(access_token=access)


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------
@auth_router.get("/session", response_model=Optional[TokenPair])
def check_session(request: Request, response: Response):
    """
    Called once on app load. If a valid refresh cookie exists, silently
    mint a new access token and tell the frontend to skip the login
    screen and redirect straight to Home (Fast Login Requirement).
    """
    refresh = request.cookies.get(REFRESH_COOKIE_NAME)
    if not refresh:
        return None
    payload = decode_jwt(refresh)
    if payload.get("type") != "refresh":
        return None
    return issue_token_pair(response, payload["sub"], remember_me=True)


@auth_router.post("/login/email", response_model=TokenPair)
def login_email(body: EmailLoginRequest, response: Response):
    user = get_user_by_email(body.email)
    if not user or not verify_password(body.password, user["hashed_password"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return issue_token_pair(response, user["user_id"], body.remember_me)


@auth_router.post("/login/phone/request-otp")
def request_otp(body: PhoneOtpRequestModel):
    code = generate_otp()
    _fake_otp_store[body.phone_number] = {
        "code": code,
        "expires_at": datetime.now(timezone.utc) + timedelta(minutes=5),
    }
    send_otp_sms(body.phone_number, code)
    return {"message": "OTP sent"}


@auth_router.post("/login/phone/verify", response_model=TokenPair)
def verify_otp(body: PhoneOtpVerifyModel, response: Response):
    record = _fake_otp_store.get(body.phone_number)
    if not record or record["code"] != body.otp_code:
        raise HTTPException(status_code=401, detail="Invalid or expired OTP")
    if datetime.now(timezone.utc) > record["expires_at"]:
        raise HTTPException(status_code=401, detail="OTP expired")
    del _fake_otp_store[body.phone_number]
    return issue_token_pair(response, f"phone:{body.phone_number}", body.remember_me)


@auth_router.post("/login/oauth", response_model=TokenPair)
def login_oauth(body: OAuthExchangeRequest, response: Response):
    profile = exchange_oauth_token(body.provider, body.id_token)
    return issue_token_pair(response, profile["user_id"], body.remember_me)


@auth_router.post("/logout")
def logout(response: Response):
    response.delete_cookie(REFRESH_COOKIE_NAME)
    return {"message": "Logged out"}


# --------------------------------------------------------------------------
# Dependency for protected routes: validates the access token
# --------------------------------------------------------------------------
def get_current_user(token: str = Depends(oauth2_scheme)) -> str:
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    payload = decode_jwt(token)
    if payload.get("type") != "access":
        raise HTTPException(status_code=401, detail="Invalid token type")
    return payload["sub"]
