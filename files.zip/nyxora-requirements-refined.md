# Nyxora — Auth, Home & Support Requirements (Refined)

## 1. Authentication

### 1.1 Supported methods
| Method | Notes |
|---|---|
| Google | OAuth, redirect straight to Home on success |
| Apple | OAuth, redirect straight to Home on success |
| Facebook | OAuth, redirect straight to Home on success |
| Phone + OTP | 6-digit code, 5-minute expiry |
| Email + Password | Standard, with "Remember Me" |
| Guest Demo Mode | Optional, future |

### 1.2 Session behavior
- Access tokens are short-lived (~15 min); refresh tokens are long-lived and stored in an httpOnly cookie — never exposed to client JS.
- "Remember Me" extends the refresh token lifetime (e.g. 30 days vs. 1 day).
- On app load, the client calls a session-check endpoint once. If a valid refresh cookie exists, the login screen is skipped entirely and the user lands on Home.
- No intermediate "setup" screens after any login method — all paths converge on Home immediately.

### 1.3 Non-functional targets
- Minimize loading screens; the auth step should feel near-instant.
- OTP and OAuth failures show inline errors without losing entered data.

## 2. Home Page

### 2.1 Required sections
- Personalized welcome
- Search bar
- Trending songs
- Recommended songs
- Recently played / continue listening
- Mood playlists
- User playlists
- Liked songs (quick access)
- Animated background (subtle, not distracting from content)
- Quick Music Actions panel (below)

### 2.2 Quick Music Actions panel
A single glass panel that lets a user act on a song without leaving Home:

1. **Paste Link** — accepts Spotify, YouTube (video or Music), Apple Music, Deezer, or SoundCloud URLs. Input validates the URL shape client-side; the backend resolves the provider and fetches metadata.
2. **Import Song / Open Player / Add to Playlist** — three explicit actions rather than one ambiguous button, so the user's intent is unambiguous to both the UI and the backend.
3. **Legal download gate** — the Download action is only enabled when the resolved track is user-uploaded, public domain, Creative Commons, or from a provider whose API explicitly permits downloads. Otherwise the UI shows the provider's own rules and links out to the official app/site. Nyxora never stores or re-serves copyrighted audio it isn't licensed for.

### 2.3 Personal uploads
- MP3 / WAV / FLAC uploads go into a private library, kept structurally separate from streamed/licensed content so download-eligibility logic never has to guess a track's origin.

## 3. Navigation

Sidebar order: Home, Search, Your Library, Playlists, Liked Songs, Recently Played, Trending, Mood Mixes, Support Center, Profile, Settings.

## 4. Support Center
Accessible from sidebar and settings: Help Center, FAQs, Report a Bug, Contact Support, Feedback, Feature Requests, Account Recovery, Payment Support (future). Channels: email now; live chat and an AI assistant bot planned.

## 5. Playback & Compliance Rules
- No autoplay — playback starts only on explicit user click, per browser autoplay policy.
- Volume preference persists across sessions.
- No pirated hosting, no unauthorized downloads, no unlicensed lyrics display, no DRM circumvention — all playback/downloads/lyrics must stay within each provider's licensing terms.

## 6. Core User Journey
```
Login → Home → Search or Play Music → View Lyrics → Create Playlist → Enjoy Music
```
No unnecessary steps inserted between login and the first play.
